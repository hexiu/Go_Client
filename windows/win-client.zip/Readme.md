# windows 客户端使用要求
- 首先在 D盘 下 创建文件夹 client 
- 然后下载 [windows 客户端信息到本地](http://7xpugm.com1.z0.glb.clouddn.com/client.exe "Windows 客户端") 下载所有的信息。 
- 然后将下载的信息放到D盘的目录下，双击client.exe，安装至D盘,然后对install.bat 点击右键 ”以管理员身份运行“即可。
- 重启电脑

